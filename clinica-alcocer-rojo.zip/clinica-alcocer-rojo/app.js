const express = require('express');
const mysql = require('mysql2/promise');
const path = require('path');
const app = express();

// Configuración de la base de datos MariaDB
const dbConfig = {
  host: process.env.MYSQL_HOST || 'mariadb',
  user: process.env.MYSQL_USER || 'alcocer_user',
  password: process.env.MYSQL_PASSWORD || 'alcocer_pass123',
  database: process.env.MYSQL_DATABASE || 'alcocer_db',
  port: process.env.MYSQL_PORT || 3306,
  charset: 'utf8mb4',
  timezone: '-05:00'
};

let connection;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));
app.set('view engine', 'ejs');

// Especialidades disponibles
const especialidades = ['pediatría', 'cardiología', 'odontología'];

// Horarios disponibles
const horarios = [
  '08:00', '09:00', '10:00', '11:00', 
  '14:00', '15:00', '16:00', '17:00'
];

// Inicializar conexión a MariaDB
async function initDB() {
  try {
    connection = await mysql.createConnection(dbConfig);
    console.log('Conectado a MariaDB');
    
    // Crear tabla si no existe
    await connection.execute(`
      CREATE TABLE IF NOT EXISTS citas (
        id INT AUTO_INCREMENT PRIMARY KEY,
        paciente_nombre VARCHAR(100) NOT NULL,
        paciente_telefono VARCHAR(20) NOT NULL,
        especialidad VARCHAR(50) NOT NULL,
        fecha DATE NOT NULL,
        hora TIME NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY unique_cita (fecha, hora, especialidad)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    `);
    
    console.log('Base de datos inicializada - Clínica Alcocer Rojo');
  } catch (err) {
    console.error('Error inicializando MariaDB:', err);
    // Reintento de conexión después de 5 segundos
    setTimeout(initDB, 5000);
  }
}

// Función para ejecutar queries de forma segura
async function executeQuery(query, params = []) {
  try {
    const [rows] = await connection.execute(query, params);
    return rows;
  } catch (err) {
    console.error('Error ejecutando query:', err);
    throw err;
  }
}

// Rutas
app.get('/', async (req, res) => {
  try {
    const citas = await executeQuery(
      'SELECT * FROM citas ORDER BY fecha DESC, hora DESC LIMIT 10'
    );
    
    res.render('index', { 
      especialidades, 
      horarios, 
      citas,
      mensaje: req.query.mensaje 
    });
  } catch (err) {
    console.error('Error cargando página principal:', err);
    res.render('index', { 
      especialidades, 
      horarios, 
      citas: [],
      error: 'Error conectando a la base de datos' 
    });
  }
});

app.post('/agendar', async (req, res) => {
  const { paciente_nombre, paciente_telefono, especialidad, fecha, hora } = req.body;
  
  try {
    // Verificar si ya existe una cita en esa fecha/hora/especialidad
    const existente = await executeQuery(
      'SELECT id FROM citas WHERE fecha = ? AND hora = ? AND especialidad = ?',
      [fecha, hora, especialidad]
    );
    
    if (existente.length > 0) {
      return res.redirect('/?mensaje=error_horario_ocupado');
    }
    
    // Insertar nueva cita
    await executeQuery(
      'INSERT INTO citas (paciente_nombre, paciente_telefono, especialidad, fecha, hora) VALUES (?, ?, ?, ?, ?)',
      [paciente_nombre, paciente_telefono, especialidad, fecha, hora]
    );
    
    res.redirect('/?mensaje=cita_agendada');
  } catch (err) {
    console.error('Error agendando cita:', err);
    res.redirect('/?mensaje=error_sistema');
  }
});

app.get('/citas', async (req, res) => {
  try {
    const citas = await executeQuery(
      'SELECT * FROM citas ORDER BY fecha ASC, hora ASC'
    );
    res.render('citas', { citas });
  } catch (err) {
    console.error('Error cargando citas:', err);
    res.render('citas', { citas: [], error: 'Error cargando citas' });
  }
});

app.delete('/cita/:id', async (req, res) => {
  try {
    await executeQuery('DELETE FROM citas WHERE id = ?', [req.params.id]);
    res.json({ success: true });
  } catch (err) {
    console.error('Error eliminando cita:', err);
    res.status(500).json({ error: 'Error eliminando cita' });
  }
});

// Endpoint de salud para verificar conexión
app.get('/health', async (req, res) => {
  try {
    await executeQuery('SELECT 1');
    res.json({ status: 'OK', database: 'MariaDB conectado' });
  } catch (err) {
    res.status(500).json({ status: 'Error', message: err.message });
  }
});

// Manejo de cierre graceful
process.on('SIGTERM', async () => {
  console.log('Cerrando conexión a MariaDB...');
  if (connection) {
    await connection.end();
  }
  process.exit(0);
});

// Inicializar servidor
const PORT = process.env.PORT || 8080;

initDB().then(() => {
  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Clínica Alcocer Rojo - Servidor corriendo en puerto ${PORT}`);
  });
});
